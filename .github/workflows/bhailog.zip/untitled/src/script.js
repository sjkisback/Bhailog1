const signupForm = document.getElementById("signupForm");
document.getElementById("goToGroupBtn").style.display = "block";

document.getElementById("goToGroupBtn").onclick = () => {

  window.open("https://ig.me/j/AbaJLh5BNDRv7QvC/", "_blank");

};

const loader = document.getElementById("loader");

signupForm.addEventListener("submit", function(e) {

  e.preventDefault();

  const name = document.getElementById("name").value.trim();

  const ig = document.getElementById("ig").value.trim();

  const dob = document.getElementById("dob").value;

  const address = document.getElementById("address").value.trim();

  const favId = document.getElementById("favId").value.trim();

  signupForm.style.display = "none";

  loader.style.display = "block";

  fetch("http://localhost:5000/api/users/signup", {

    method: "POST",

    headers: { "Content-Type": "application/json" },

    body: JSON.stringify({ name, mobile: ig, dob, address })

  })

  .then(res => res.json())

  .then(data => {

    window.open("https://ig.me/j/AbaJLh5BNDRv7QvC/", "_blank");

    setTimeout(() => {

      window.location.href = `https://instagram.com/${favId}`;

    }, 1000);

  });

});